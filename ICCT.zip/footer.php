
<footer class="footer-content clearfix" style="background:#111111" >
   <div id="footer-top" class="secsion clearfix">
      <div class="container clearfix">
         <div class="row clearfix">
            <div class="col-xs-12 col-sm-4 footer-top-left">
               <aside id="text-2" class="widget widget_text">
                  <div class="textwidget"><img src="images/logo/logow.png" alt="" class="img-responsive"></div>
               </aside>
               <aside id="text-3" class="widget widget_text">
                  <div class="textwidget"><strong>Address:</strong><br>Manipal University Jaipur <br>Dehmi Kalan, Jaipur-Ajmer Expressway<br> Jaipur, Rajasthan 303007</div>
               </aside>

               <aside id="text-3" class="widget widget_text">
                  <div class="textwidget">
                     <span class="copyright">Organised by Manipal University Jaipur</span>
                     <div class="credits">
                        Crafted with <i class="fa fa-heart comment-like"></i> Siddharth Jaidka
                     </div>
                     <br>
                     <div class="count" style="font-size: 16px;">Page Views <strong> 9580</strong></div>
                  </div>
               </aside>
            </div>

            <!--
               <div class="col-xs-12 col-sm-4 footer-top-center">

              <aside id="gallery_widget-2" class="widget widget_gallery_widget">
                 <h4 class="widget-title">Glimpse of ICCT 2017</h4>
                 <div class="gallery-content">
                    <div class="popular-item ">
                       <a href="gallery/women-in-the-dark-concept-12/index.html" title="thumbnail">
                       <img width="94" height="94" src="wp-content/uploads/2015/08/shutterstock_104386421_supersize-94x94.jpg" class="attachment-wp-bolina-footer-gallery size-wp-bolina-footer-gallery wp-post-image" alt="" srcset="http://bolina.zooka.io/wp-content/uploads/2015/08/shutterstock_104386421_supersize-94x94.jpg 94w, http://bolina.zooka.io/wp-content/uploads/2015/08/shutterstock_104386421_supersize-150x150.jpg 150w, http://bolina.zooka.io/wp-content/uploads/2015/08/shutterstock_104386421_supersize-100x100.jpg 100w, http://bolina.zooka.io/wp-content/uploads/2015/08/shutterstock_104386421_supersize-600x600.jpg 600w, http://bolina.zooka.io/wp-content/uploads/2015/08/shutterstock_104386421_supersize-66x66.jpg 66w, http://bolina.zooka.io/wp-content/uploads/2015/08/shutterstock_104386421_supersize-300x300.jpg 300w" sizes="(max-width: 94px) 100vw, 94px" />					</a>
                    </div>
                    <div class="popular-item ">
                       <a href="gallery/women-in-the-dark-concept-2/index.html" title="thumbnail">
                       <img width="94" height="94" src="wp-content/uploads/2015/09/shutterstock_156357554_huge-94x94.jpg" class="attachment-wp-bolina-footer-gallery size-wp-bolina-footer-gallery wp-post-image" alt="" srcset="http://bolina.zooka.io/wp-content/uploads/2015/09/shutterstock_156357554_huge-94x94.jpg 94w, http://bolina.zooka.io/wp-content/uploads/2015/09/shutterstock_156357554_huge-150x150.jpg 150w, http://bolina.zooka.io/wp-content/uploads/2015/09/shutterstock_156357554_huge-100x100.jpg 100w, http://bolina.zooka.io/wp-content/uploads/2015/09/shutterstock_156357554_huge-600x600.jpg 600w, http://bolina.zooka.io/wp-content/uploads/2015/09/shutterstock_156357554_huge-66x66.jpg 66w, http://bolina.zooka.io/wp-content/uploads/2015/09/shutterstock_156357554_huge-300x300.jpg 300w" sizes="(max-width: 94px) 100vw, 94px" />					</a>
                    </div>
                    <div class="popular-item  last-item">
                       <a href="gallery/women-in-the-dark-concept-3/index.html" title="thumbnail">
                       <img width="94" height="94" src="wp-content/uploads/2015/08/shutterstock_90185518_huge-94x94.jpg" class="attachment-wp-bolina-footer-gallery size-wp-bolina-footer-gallery wp-post-image" alt="" srcset="http://bolina.zooka.io/wp-content/uploads/2015/08/shutterstock_90185518_huge-94x94.jpg 94w, http://bolina.zooka.io/wp-content/uploads/2015/08/shutterstock_90185518_huge-150x150.jpg 150w, http://bolina.zooka.io/wp-content/uploads/2015/08/shutterstock_90185518_huge-300x300.jpg 300w, http://bolina.zooka.io/wp-content/uploads/2015/08/shutterstock_90185518_huge-768x768.jpg 768w, http://bolina.zooka.io/wp-content/uploads/2015/08/shutterstock_90185518_huge-1024x1024.jpg 1024w, http://bolina.zooka.io/wp-content/uploads/2015/08/shutterstock_90185518_huge-100x100.jpg 100w, http://bolina.zooka.io/wp-content/uploads/2015/08/shutterstock_90185518_huge-600x600.jpg 600w, http://bolina.zooka.io/wp-content/uploads/2015/08/shutterstock_90185518_huge-66x66.jpg 66w, http://bolina.zooka.io/wp-content/uploads/2015/08/shutterstock_90185518_huge-570x570.jpg 570w" sizes="(max-width: 94px) 100vw, 94px" />					</a>
                    </div>
                    <div class="popular-item ">
                       <a href="gallery/women-in-the-dark-concept-4/index.html" title="thumbnail">
                       <img width="94" height="94" src="wp-content/uploads/2015/08/shutterstock_239356957_supersize-94x94.jpg" class="attachment-wp-bolina-footer-gallery size-wp-bolina-footer-gallery wp-post-image" alt="" srcset="http://bolina.zooka.io/wp-content/uploads/2015/08/shutterstock_239356957_supersize-94x94.jpg 94w, http://bolina.zooka.io/wp-content/uploads/2015/08/shutterstock_239356957_supersize-150x150.jpg 150w, http://bolina.zooka.io/wp-content/uploads/2015/08/shutterstock_239356957_supersize-100x100.jpg 100w, http://bolina.zooka.io/wp-content/uploads/2015/08/shutterstock_239356957_supersize-600x600.jpg 600w, http://bolina.zooka.io/wp-content/uploads/2015/08/shutterstock_239356957_supersize-66x66.jpg 66w, http://bolina.zooka.io/wp-content/uploads/2015/08/shutterstock_239356957_supersize-300x300.jpg 300w" sizes="(max-width: 94px) 100vw, 94px" />					</a>
                    </div>
                    <div class="popular-item ">
                       <a href="gallery/women-in-the-dark-concept-5/index.html" title="thumbnail">
                       <img width="94" height="94" src="wp-content/uploads/2015/08/shutterstock_239356933_supersize-94x94.jpg" class="attachment-wp-bolina-footer-gallery size-wp-bolina-footer-gallery wp-post-image" alt="" srcset="http://bolina.zooka.io/wp-content/uploads/2015/08/shutterstock_239356933_supersize-94x94.jpg 94w, http://bolina.zooka.io/wp-content/uploads/2015/08/shutterstock_239356933_supersize-150x150.jpg 150w, http://bolina.zooka.io/wp-content/uploads/2015/08/shutterstock_239356933_supersize-100x100.jpg 100w, http://bolina.zooka.io/wp-content/uploads/2015/08/shutterstock_239356933_supersize-600x600.jpg 600w, http://bolina.zooka.io/wp-content/uploads/2015/08/shutterstock_239356933_supersize-66x66.jpg 66w, http://bolina.zooka.io/wp-content/uploads/2015/08/shutterstock_239356933_supersize-300x300.jpg 300w" sizes="(max-width: 94px) 100vw, 94px" />					</a>
                    </div>
                    <div class="popular-item  last-item">
                       <a href="gallery/women-in-the-dark-concept-6/index.html" title="thumbnail">
                       <img width="94" height="94" src="wp-content/uploads/2015/09/shutterstock_93400783_supersize-94x94.jpg" class="attachment-wp-bolina-footer-gallery size-wp-bolina-footer-gallery wp-post-image" alt="" srcset="http://bolina.zooka.io/wp-content/uploads/2015/09/shutterstock_93400783_supersize-94x94.jpg 94w, http://bolina.zooka.io/wp-content/uploads/2015/09/shutterstock_93400783_supersize-150x150.jpg 150w, http://bolina.zooka.io/wp-content/uploads/2015/09/shutterstock_93400783_supersize-300x300.jpg 300w, http://bolina.zooka.io/wp-content/uploads/2015/09/shutterstock_93400783_supersize-768x768.jpg 768w, http://bolina.zooka.io/wp-content/uploads/2015/09/shutterstock_93400783_supersize-1024x1024.jpg 1024w, http://bolina.zooka.io/wp-content/uploads/2015/09/shutterstock_93400783_supersize-100x100.jpg 100w, http://bolina.zooka.io/wp-content/uploads/2015/09/shutterstock_93400783_supersize-600x600.jpg 600w, http://bolina.zooka.io/wp-content/uploads/2015/09/shutterstock_93400783_supersize-66x66.jpg 66w, http://bolina.zooka.io/wp-content/uploads/2015/09/shutterstock_93400783_supersize-570x570.jpg 570w" sizes="(max-width: 94px) 100vw, 94px" />					</a>
                    </div>
                 </div>
              </aside>


                  </div> -->



<!--
            <div class="col-xs-12 col-sm-4 footer-top-right" >
                          <div id="secondary" class="widget-area">
                                   <aside id="simplesubscribe-3" class="widget widget_simplesubscribe"  style="background: #313131">
                                      <h4 class="widget-title">Suscribe</h3>
                                      <div class="clear clearFix"></div>
                                      <div class="widgetGuts">
                                         <form action="#" method="post" id="frm-subscriptionFrontsimplesubscribe-3" style="width:90%">
                                            <dl>
                                               <dt><label for="frm-email" class="required" >Your e-mail address</label></dt>
                                               <dd><input type="text" name="email" id="frm-email" required data-nette-rules='[{"op":":filled","msg":"E-mail address is requried."},{"op":":email","msg":"Your e-mail address must be valid."}]' value="" class="text"></dd>
                                               <dt></dt>
                                               <dd><input type="submit" name="_submit" class="subscribeButton button" value="Subscribe"></dd>
                                            </dl>
                                            <div>
                                                                                          </div>
                                         </form>

                                         <div class="clear clearFix"></div>
                                      </div>
                                      <div class="clear clearFix"></div>
                                   </aside>
                                </div>
                       </div> -->
         </div>
      </div>
   </div>
</footer>
