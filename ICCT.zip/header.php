<header id="masthead" class="site-header">
   <!--Header current-menu-ancestor-->
   <div id="cshero-header" class="cshero-main-header v1     ">
      <div class="section wrap-navigation">
         <div class="container-fluid padding-lr-106">
            <div class="row">
               <div id="cshero-header-logo" class="header-logo col-xs-12 col-sm-12 col-md-2 col-lg-2">
                   <a href="index.html"><img class="img-responsive" alt="" src="images/logo/logob.png"></a>
               </div>
               <div id="cshero-header-logo-sticky" class="header-logo col-xs-12 col-sm-12 col-md-2 col-lg-2">
                   <a href="index.html"><img class="img-responsive" alt="" src="images/logo/logow.png"></a>
               </div>
               <div id="cshero-header-navigation" class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
                  <nav id="site-navigation" class="main-navigation">
                     <div class="menu-menu-navigation-container">
                        <ul id="menu-menu-navigation" class="nav-menu menu-main-menu">
                           <li id="menu-item-511" class="menu-item menu-item-type-custom menu-item-object-custom  menu-item-has-children no_group menu-item-511 element1" data-depth="0">
                              <a href="index.php"><span class="menu-title">Home</span></a>
                           </li>
                           <li id="menu-item-58" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children no_group menu-item-58 element2" data-depth="0">
                              <a href="track.php"><span class="menu-title">Tracks</span></a>

                           </li>
                           <li id="menu-item-743" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children no_group menu-item-743 element3" data-depth="0">
                              <a href="registration.php"><span class="menu-title">Registration</span></a>
                           </li>
                           <li id="menu-item-2746" class="menu-item menu-item-type-post_type menu-item-object-page no_group menu-item-2746 element4" data-depth="0"><a href="publication.php"><span class="menu-title">Publication</span></a></li>
                           <!-- <li id="menu-item-1158" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children no_group menu-item-1158 element5" data-depth="0">
                              <a href="#"><span class="menu-title">Committee</span></a>
                              <ul class='standar-dropdown standard autodrop_submenu sub-menu' style="width:200px;">
                                 <li id="menu-item-861" class="menu-item menu-item-type-post_type menu-item-object-page no_group menu-item-861" data-depth="1"><a href="blog/index.html"><span class="menu-title">Blog no sidebar</span></a></li>
                                 <li id="menu-item-1161" class="menu-item menu-item-type-post_type menu-item-object-page no_group menu-item-1161" data-depth="1"><a href="blog-width-sidebar/index.html"><span class="menu-title">Blog with sidebar</span></a></li>
                                 <li id="menu-item-1164" class="menu-item menu-item-type-post_type menu-item-object-page no_group menu-item-1164" data-depth="1"><a href="blog-grid-width-sidebar/index.html"><span class="menu-title">Blog grid with sidebar</span></a></li>
                                 <li id="menu-item-1167" class="menu-item menu-item-type-post_type menu-item-object-page no_group menu-item-1167" data-depth="1"><a href="blog-standard/index.html"><span class="menu-title">Blog standard</span></a></li>
                              </ul>
                           </li> -->
                           <!-- <li id="menu-item-758" class="menu-item menu-item-type-post_type menu-item-object-page no_group menu-item-758 element6" data-depth="0"><a href="contact-us/index.html"><span class="menu-title">Sponsors</span></a></li> -->
                           <li id="menu-item-758" class="menu-item menu-item-type-post_type menu-item-object-page no_group menu-item-758 element7" data-depth="0"><a href="contact.php"><span class="menu-title">Contact</span></a></li>
                        </ul>
                     </div>
                  </nav>
               </div>
               <div id="right-header" class="col-xs-12 col-sm-12 col-md-2 col-lg-2">
                  <div class="pull-right">
                     <div class="woo-cart">
                        <div class="widget_cart_search_wrap">
                           <div class="header">
                              <a href="javascript:void(0)" class="icon_cart_wrap" id = "clicker" data-display=".shopping_cart_dropdown" data-no_display=".widget_searchform_content"><i class="fa fa-info" style="color:#000"></i><span class="cart_total"> 4</span></a>
                           </div>
                           <div class="shopping_cart_dropdown" style="font-size:12px">
                              <div class="shopping_cart_dropdown_inner">
                                 <ul class="cart_list product_list_widget">
                                    <li class="cart-list clearfix">Important Dates</li>
                                 </ul>
                              </div>
                              <a href="cart/index.html" class="btn btn-primary left wc-forward">1<sup>st</sup>Oct'18 &nbsp</a>
                              <span class="total right">Call for Papers<span><span class="woocommerce-Price-amount amount"></span></span></span>
                              <br>
                              <a href="cart/index.html" class="btn btn-primary left wc-forward">21<sup>st</sup>Jan'19</a>
                              <span class="total right">Paper Submission by<span><span class="woocommerce-Price-amount amount"></span></span></span>
                              <br>
                              <a href="cart/index.html" class="btn btn-primary left wc-forward">31<sup>st</sup>Jan'19</a>
                              <span class="total right">Notification of Acceptance: <span><span class="woocommerce-Price-amount amount"> </span></span></span>
                              <br>
                              <a href="cart/index.html" class="btn btn-primary left wc-forward">15<sup>th</sup>Feb'19</a>
                              <span class="total right">Camera Ready Submission by <span><span class="woocommerce-Price-amount amount"> </span></span></span>
                           </div>
                        </div>
                     </div>
                     <div class="menu-canvas">
                        <span class="button-menu "><i class="fa fa-bars" style="color:#000; margin-left:0.3em"></i></span>
                        <nav class="main-canvas">
                           <div class="menu-menu-verticle-container" style="margin-right:2vw;">
                             <br>
                              <ul id="menu-menu-verticle" class="nav-menu menu-main-menu">
                                 <li id="menu-item-2802" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-ancestor current-menu-parent menu-item-has-children no_group menu-item-2802" data-depth="0">
                                    <a href="index.php"><span class="menu-title">Home</span></a>
                                 </li>
                                 <li id="menu-item-2816" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children no_group menu-item-2816" data-depth="0">
                                    <a href="tracks.php"><span class="menu-title">Track</span></a>

                                 </li>
                                 <li id="menu-item-2818" class="menu-item menu-item-type-post_type menu-item-object-page no_group menu-item-2818" data-depth="0"><a href="shop/index.html"><span class="menu-title">Speakers</span></a></li>
                                 <li id="menu-item-2819" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children no_group menu-item-2819" data-depth="0">
                                    <a href="registration.php"><span class="menu-title">Registration</span></a>
                                 </li>
                                 <!-- <li id="menu-item-2825" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children no_group menu-item-2825" data-depth="0">
                                    <a href="#"><span class="menu-title">Camera Ready Submission</span></a>
                                 </li> -->
                                 <li id="menu-item-2824" class="menu-item menu-item-type-post_type menu-item-object-page no_group menu-item-2824" data-depth="0"><a href="publication.php"><span class="menu-title">Publication</span></a></li>
                                 <!-- <li id="menu-item-2824" class="menu-item menu-item-type-post_type menu-item-object-page no_group menu-item-2824" data-depth="0"><a href="committee.php"><span class="menu-title">Committees</span></a></li> -->
                                 <!-- <li id="menu-item-2824" class="menu-item menu-item-type-post_type menu-item-object-page no_group menu-item-2824" data-depth="0"><a href="contact-us/index.html"><span class="menu-title">Sponsors</span></a></li> -->
                                 <li id="menu-item-2824" class="menu-item menu-item-type-post_type menu-item-object-page no_group menu-item-2824" data-depth="0"><a href="contact.php"><span class="menu-title">Contact Us</span></a></li>
                              </ul>
                           </div>
                           <span class="close-menu"><i class="fa fa-times"></i></span>
                        </nav>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</header>


<!--Simple Script to select the current Tab -->
<script>
var tabToSelect = parseInt(<?php echo $tabToSelect ?>);
console.log("element"+tabToSelect);
var currentTab = document.getElementsByClassName("element"+tabToSelect);
currentTab[0].className += " current-menu-ancestor";
</script>
