<!-- #page -->
<script type="text/javascript">
   function revslider_showDoubleJqueryError(sliderID) {
    var errorMessage = "Revolution Slider Error: You have some jquery.js library include that comes after the revolution files js include.";
    errorMessage += "<br> This includes make eliminates the revolution slider libraries, and make it not work.";
    errorMessage += "<br><br> To fix it you can:<br>&nbsp;&nbsp;&nbsp; 1. In the Slider Settings -> Troubleshooting set option:  <strong><b>Put JS Includes To Body</b></strong> option to true.";
    errorMessage += "<br>&nbsp;&nbsp;&nbsp; 2. Find the double jquery.js include and remove it.";
    errorMessage = "<span style='font-size:16px;color:#BC0C06;'>" + errorMessage + "</span>";
      jQuery(sliderID).show().html(errorMessage);
   }
</script>
<link property="stylesheet" rel='stylesheet' id='vc_google_fonts_lato100100italic300300italicregularitalic700700italic900900italic-css'  href='http://fonts.googleapis.com/css?family=Lato%3A100%2C100italic%2C300%2C300italic%2Cregular%2Citalic%2C700%2C700italic%2C900%2C900italic&amp;ver=4.7.10' type='text/css' media='all' />
<link rel='stylesheet' id='cms-icon-pe7stroke-css'  href='plugins/cmssuperheroes/assets/css/Pe-icon-7-stroked714.css?ver=4.7.10' type='text/css' media='all' />
<link rel='stylesheet' id='mediaelement-css'  href='js/mediaelement/mediaelementplayer.min51cd.css?ver=2.22.0' type='text/css' media='all' />
<link rel='stylesheet' id='wp-mediaelement-css'  href='js/mediaelement/wp-mediaelement.mind714.css?ver=4.7.10' type='text/css' media='all' />
<link property="stylesheet" rel='stylesheet' id='owl-carousel-css'  href='plugins/cmssuperheroes/assets/css/owl.carousel30b5.css?ver=2.0.0b' type='text/css' media='all' />
<script type='text/javascript' src='plugins/contact-form-7/includes/js/jquery.form.mind03d.js?ver=3.51.0-2014.06.20'></script>
<script type='text/javascript'>
   /* <![CDATA[ */
   var _wpcf7 = {"recaptcha":{"messages":{"empty":"Please verify that you are not a robot."}},"cached":"1"};
   /* ]]> */
</script>
<script type='text/javascript' src='plugins/contact-form-7/includes/js/scripts1c9b.js?ver=4.6.1'></script>
<script type='text/javascript' src='plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min44fd.js?ver=2.70'></script>

<script type='text/javascript' src='plugins/woocommerce/assets/js/frontend/woocommerce.min72e6.js?ver=2.6.4'></script>
<script type='text/javascript' src='plugins/woocommerce/assets/js/jquery-cookie/jquery.cookie.min330a.js?ver=1.4.1'></script>
<script type='text/javascript'>
   /* <![CDATA[ */
   var wc_cart_fragments_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","fragment_name":"wc_fragments"};
   /* ]]> */
</script>
<script type='text/javascript' src='plugins/woocommerce/assets/js/frontend/cart-fragments.min72e6.js?ver=2.6.4'></script>
<script type='text/javascript' src='themes/assets/js/scroll_effectcfa9.js?ver=1.1.2'></script>
<script type='text/javascript' src='themes/assets/js/parallaxe7f0.js?ver=1.3.1'></script>
<script type='text/javascript'>
   var CMSOptions = {"menu_sticky":"1","menu_sticky_tablets":"","menu_sticky_mobile":"","paralax":"1","back_to_top":"1",};
</script>
<script type='text/javascript' src='themes/assets/js/main8a54.js?ver=1.0.0'></script>
<script type='text/javascript' src='themes/assets/js/menu8a54.js?ver=1.0.0'></script>
<script type='text/javascript' src='plugins/simple-subscribe/assets/netteForms8a54.js?ver=1.0.0'></script>
<script type='text/javascript' src='js/wp-embed.mind714.js?ver=4.7.10'></script>
<script type='text/javascript' src='plugins/js_composer/assets/js/dist/js_composer_front.min0147.js?ver=4.12'></script>
<script type='text/javascript' src='plugins/js_composer/assets/lib/waypoints/waypoints.min0147.js?ver=4.12'></script>
<script type='text/javascript' src='js/mediaelement/mediaelement-and-player.min51cd.js?ver=2.22.0'></script>
<script type='text/javascript' src='js/mediaelement/wp-mediaelement.mind714.js?ver=4.7.10'></script>
<script type='text/javascript' src='plugins/cmssuperheroes/assets/js/cmsgrid.pagination8a54.js?ver=1.0.0'></script>
<script type='text/javascript' src='plugins/cmssuperheroes/assets/js/modernizr.mind714.js?ver=4.7.10'></script>
<script type='text/javascript' src='js/imagesloaded.min55a0.js?ver=3.2.0'></script>
<script type='text/javascript' src='plugins/cmssuperheroes/assets/js/jquery.shuffled714.js?ver=4.7.10'></script>
<script type='text/javascript' src='themes/assets/js/jquery.shuffle.cmsd714.js?ver=4.7.10'></script>
<script type='text/javascript'>
   /* <![CDATA[ */
   var cms_more_objcms_grid = {"startPage":"1","maxPages":"2","total":"12","perpage":"8","nextLink":"http:\/\/bolina.zooka.io\/page\/2\/","masonry":"masonry"};
   /* ]]> */
</script>
<script type='text/javascript' src='themes/assets/js/cms_loadmore_gallery5152.js?ver=1.0'></script>
<script type='text/javascript' src='plugins/cmssuperheroes/assets/js/owl.carousel.min30b5.js?ver=2.0.0b'></script>
<script type='text/javascript'>
   /* <![CDATA[ */
   var cmscarousel = {"cms-carousel":{"margin":"35","loop":"false","mouseDrag":"true","nav":"false","dots":"false","autoplay":"false","autoplayTimeout":5000,"smartSpeed":1000,"autoplayHoverPause":"true","navText":["<i class=\"fa fa-arrow-left\"><\/i>","<i class=\"fa fa-arrow-right\"><\/i>"],"dotscontainer":"cms-carousel .cms-dots","responsive":{"0":{"items":1},"768":{"items":2},"992":{"items":4},"1200":{"items":6}}}};
   /* ]]> */
</script>
<script type='text/javascript' src='plugins/cmssuperheroes/assets/js/owl.carousel.cms8a54.js?ver=1.0.0'></script>
<script type='text/javascript' src='plugins/cmssuperheroes/assets/js/counter.min8a54.js?ver=1.0.0'></script>
<script type='text/javascript' src='plugins/cmssuperheroes/assets/js/counter.cms8a54.js?ver=1.0.0'></script>
