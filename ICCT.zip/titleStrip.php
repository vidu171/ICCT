<div id="page-title" class="page-title" style="background-image: url(<?php echo $imageUrl?>);">
<div class="container-fluid">
  <div class="page-title-overlay" style="background:rgba(0, 0, 0, 0.2)"></div>
  <div class="row">
     <div class="container">
        <div id="page-title-text" class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
           <h1 style="color:#fff">
          <?php echo $pageName ?>                                      <span class="page-title-line" style="background:#ffbf00"></span>
           </h1>
        </div>
        <div id="breadcrumb-text" class="col-xs-12 col-sm-12 col-md-12 col-lg-12"
           style="color:#fff">
           <ul class="breadcrumbs">
              <li><a style="color:#fff" href="index.php">Home</a></li>
              <li><?php echo $pageName ?></li>
           </ul>
        </div>
     </div>
  </div>
</div>
</div>
