
   <meta charset="UTF-8"/>
   <meta name="viewport" content="initial-scale=1,width=device-width">

   <link rel='dns-prefetch' href='http://fonts.googleapis.com/' />

   <script type="text/javascript">
      window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.2.1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.2.1\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/bolina.zooka.io\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.7.10"}};
      !function(a,b,c){function d(a){var b,c,d,e,f=String.fromCharCode;if(!k||!k.fillText)return!1;switch(k.clearRect(0,0,j.width,j.height),k.textBaseline="top",k.font="600 32px Arial",a){case"flag":return k.fillText(f(55356,56826,55356,56819),0,0),!(j.toDataURL().length<3e3)&&(k.clearRect(0,0,j.width,j.height),k.fillText(f(55356,57331,65039,8205,55356,57096),0,0),b=j.toDataURL(),k.clearRect(0,0,j.width,j.height),k.fillText(f(55356,57331,55356,57096),0,0),c=j.toDataURL(),b!==c);case"emoji4":return k.fillText(f(55357,56425,55356,57341,8205,55357,56507),0,0),d=j.toDataURL(),k.clearRect(0,0,j.width,j.height),k.fillText(f(55357,56425,55356,57341,55357,56507),0,0),e=j.toDataURL(),d!==e}return!1}function e(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var f,g,h,i,j=b.createElement("canvas"),k=j.getContext&&j.getContext("2d");for(i=Array("flag","emoji4"),c.supports={everything:!0,everythingExceptFlag:!0},h=0;h<i.length;h++)c.supports[i[h]]=d(i[h]),c.supports.everything=c.supports.everything&&c.supports[i[h]],"flag"!==i[h]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[i[h]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(g=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",g,!1),a.addEventListener("load",g,!1)):(a.attachEvent("onload",g),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),f=c.source||{},f.concatemoji?e(f.concatemoji):f.wpemoji&&f.twemoji&&(e(f.twemoji),e(f.wpemoji)))}(window,document,window._wpemojiSettings);
   </script>

   <link rel='stylesheet' id='cms-plugin-stylesheet-css'  href='plugins/cmssuperheroes/assets/css/cms-styled714.css?ver=4.7.10' type='text/css' media='all' />
   <link rel='stylesheet' id='contact-form-7-css'  href='plugins/contact-form-7/includes/css/styles1c9b.css?ver=4.6.1' type='text/css' media='all' />
   <style id='rs-plugin-settings-inline-css' type='text/css'>
      .tp-caption a{color:#ff7302;text-shadow:none;-webkit-transition:all 0.2s ease-out;-moz-transition:all 0.2s ease-out;-o-transition:all 0.2s ease-out;-ms-transition:all 0.2s ease-out}.tp-caption a:hover{color:#ffa902}
   </style>
<link rel='stylesheet' id='wp-bolina-static-css'  href='themes/assets/css/custom.css' type='text/css' media='all' />
   <link rel='stylesheet' id='wp-bolina-static-css'  href='themes/assets/css/static8a54.css' type='text/css' media='all' />
   <link rel='stylesheet' id='default-template-css'  href='plugins/simple-subscribe/extension/readygraph/assets/css/default-popupd714.css?ver=4.7.10' type='text/css' media='all' />
   <link rel='stylesheet' id='woocommerce-layout-css'  href='plugins/woocommerce/assets/css/woocommerce-layout72e6.css?ver=2.6.4' type='text/css' media='all' />
   <link rel='stylesheet' id='woocommerce-smallscreen-css'  href='plugins/woocommerce/assets/css/woocommerce-smallscreen72e6.css?ver=2.6.4' type='text/css' media='only screen and (max-width: 768px)' />
   <link rel='stylesheet' id='woocommerce-general-css'  href='plugins/woocommerce/assets/css/woocommerce72e6.css?ver=2.6.4' type='text/css' media='all' />
   <link rel='stylesheet' id='wp-bolina-hover-css'  href='themes/assets/css/hover4c56.css?ver=2.0.2' type='text/css' media='all' />
   <link rel='stylesheet' id='bootstrap-min-css'  href='themes/assets/css/bootstrap.mind617.css?ver=3.3.2' type='text/css' media='all' />
   <link rel='stylesheet' id='popup-style-css'  href='themes/assets/css/popup8a54.css?ver=1.0.0' type='text/css' media='all' />
   <link rel='stylesheet' id='scrolleffects-css'  href='themes/assets/css/animatef269.css?ver=1.0.1' type='text/css' media='all' />
   <link rel='stylesheet' id='font-awesome-css'  href='plugins/js_composer/assets/lib/bower/font-awesome/css/font-awesome.min0147.css?ver=4.12' type='text/css' media='all' />
   <link rel='stylesheet' id='font-pe7-css'  href='themes/assets/css/pe-icon-7-stroke5152.css?ver=1.0' type='text/css' media='all' />
   <link rel='stylesheet' id='wp-bolina-style-css'  href='themes/styled714.css?ver=4.7.10' type='text/css' media='all' />
   <link rel='stylesheet' id='woocommerce-css'  href='themes/assets/css/woocommerce8a54.css?ver=1.0.0' type='text/css' media='all' />
   <link rel='stylesheet' id='widget_cart_search_scripts-css'  href='themes/inc/widgets/widgetsd714.css?ver=4.7.10' type='text/css' media='all' />
   <link rel='stylesheet' id='core-css'  href='plugins/simple-subscribe/assets/styleFrontEndd714.css?ver=4.7.10' type='text/css' media='all' />
   <link rel='stylesheet' id='js_composer_front-css'  href='plugins/js_composer/assets/css/js_composer.min0147.css?ver=4.12' type='text/css' media='all' />
   <link rel='stylesheet' id='js_composer_custom_css-css'  href='js/js_composer/custom0147.css?ver=4.12' type='text/css' media='all' />
   <link rel='stylesheet' id='redux-google-fonts-smof_data-css'  href='http://fonts.googleapis.com/css?family=Lato%3A100%2C300%2C400%2C700%2C900%2C100italic%2C300italic%2C400italic%2C700italic%2C900italic%7CMerriweather%3A300%2C400%2C700%2C900%2C300italic%2C400italic%2C700italic%2C900italic%7CPlayfair+Display%3A400%2C700%2C900%2C400italic%2C700italic%2C900italic&amp;subset=latin&amp;ver=1465975237' type='text/css' media='all' />
   <script type='text/javascript' src='js/jquery/jqueryb8ff.js?ver=1.12.4'></script>
   <script type='text/javascript' src='js/jquery/jquery-migrate.min330a.js?ver=1.4.1'></script>
   <script type='text/javascript' src='plugins/revslider/js/jquery.themepunch.tools.minad79.js?ver=5.2.5.3'></script>
   <script type='text/javascript' src='plugins/revslider/js/jquery.themepunch.revolution.minad79.js?ver=5.2.5.3'></script>
   <link rel='stylesheet' id='rs-plugin-settings-css'  href='plugins/revslider/css/settingsad79.css?ver=5.2.5.3' type='text/css' media='all' />
   <script type='text/javascript'>
      /* <![CDATA[ */
      var wc_add_to_cart_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View Cart","cart_url":"http:\/\/bolina.zooka.io\/cart\/","is_cart":"","cart_redirect_after_add":"no"};
      /* ]]> */
   </script>
   <script type='text/javascript' src='plugins/woocommerce/assets/js/frontend/add-to-cart.min72e6.js?ver=2.6.4'></script>
   <script type='text/javascript' src='plugins/js_composer/assets/js/vendors/woocommerce-add-to-cart0147.js?ver=4.12'></script>
   <script type='text/javascript' src='themes/assets/js/bootstrap.mind617.js?ver=3.3.2'></script>
   <script type='text/javascript' src='themes/assets/js/popup.min8a54.js?ver=1.0.0'></script>
   <script type='text/javascript' src='themes/inc/widgets/widgetsd714.js?ver=4.7.10'></script>
   <link rel='https://api.w.org/' href='wp-json/index.html' />
   <link rel="EditURI" type="application/rsd+xml" title="RSD" href="xmlrpc0db0.php?rsd" />
   <meta name="generator" content="WordPress 4.7.10" />
   <meta name="generator" content="WooCommerce 2.6.4" />
   <link rel="canonical" href="index.html" />
   <link rel='shortlink' href='index.html' />
   <link rel="alternate" type="application/json+oembed" href="wp-json/oembed/1.0/embedd87b.json?url=http%3A%2F%2Fbolina.zooka.io%2F" />
   <link rel="alternate" type="text/xml+oembed" href="wp-json/oembed/1.0/embedcd88?url=http%3A%2F%2Fbolina.zooka.io%2F&amp;format=xml" />
   <style type="text/css" data-type="cms_shortcodes-custom-css">#cshero-header .wrap-navigation.header-fixed .main-navigation .nav-menu > li > a{color:#fff!important}#cshero-header.phones-nav{background:#fff!important}#cshero-header.tablets-nav{background:#fff!important}</style>
   <script type="text/javascript"> var ajaxurl = "http://bolina.zooka.io/wp-admin/admin-ajax.php"; </script>
   <meta name="generator" content="Powered by Slider Revolution 5.2.5.3 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
   <style type="text/css" title="dynamic-css" class="options-output">#cshero-header .wrap-navigation.header-fixed .main-navigation .nav-menu > li > a{color:#ffffff;}.wrap-navigation.header-fixed{background-color:rgba(0,0,0,0.5);}.menu-canvas .main-canvas{background-color:rgba(0,0,0,0.9);}.menu-canvas .main-canvas a{color:#ffffff;}.page-title{background-repeat:no-repeat;background-size:cover;background-position:center top;background-image:url('images/placeholder.png');}.page-title #page-title-text h1{color:#000000;}.page-title #breadcrumb-text,.page-title #breadcrumb-text ul li a{font-family:Lato;font-weight:normal;font-style:normal;color:#000000;}footer.footer-content{background-color:#111111;background-repeat:no-repeat;background-attachment:scroll;}footer .widget{color:#ffffff;}a{color:#000000;}body{font-family:Lato;line-height:23px;font-weight:300;font-style:normal;color:#999999;font-size:14px;}h1{font-family:Lato;line-height:84px;font-weight:900;font-style:normal;color:#010101;font-size:70px;}h2{font-family:Lato;line-height:59px;font-weight:900;font-style:normal;color:#000000;font-size:49px;}h3{font-family:Lato;line-height:48px;font-weight:900;font-style:normal;color:#000000;font-size:35px;}h4{font-family:Lato;line-height:24px;font-weight:900;font-style:normal;color:#000000;font-size:20px;}h5{font-family:Lato;line-height:17px;font-weight:700;font-style:normal;color:#000000;font-size:14px;}h6{font-family:Lato;line-height:15px;font-weight:400;font-style:normal;color:#000000;font-size:12px;}</style>
   <style type="text/css" data-type="vc_shortcodes-custom-css">.vc_custom_1439979297102{padding-top: 29px !important;}.vc_custom_1443147497373{padding-top: 107px !important;padding-bottom: 110px !important;}.vc_custom_1440056683991{background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}.vc_custom_1448310420520{padding-top: 98px !important;background-color: #f7f7f7 !important;}.vc_custom_1453351131776{padding-bottom: 111px !important;background-color: #f7f7f7 !important;}.vc_custom_1448251092742{padding-top: 240px !important;padding-bottom: 212px !important;background-image: url(uploads/2015/08/row_bg195dc.png?id=29) !important;background-position: 0 0 !important;background-repeat: no-repeat !important;}.vc_custom_1448212797195{padding-top: 117px !important;padding-bottom: 135px !important;background-image: url(images/placeholder.png) !important;}.vc_custom_1443407955762{padding-top: 109px !important;padding-bottom: 132px !important;background-color: #f7f7f7 !important;}.vc_custom_1443154112840{padding-top: 75px !important;padding-bottom: 75px !important;}.vc_custom_1440002709619{background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}.vc_custom_1443408260985{background-color: #F7F7F7 !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}.vc_custom_1440002723751{background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}.vc_custom_1443407455571{background-color: #f7f7f7 !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}.vc_custom_1440002295125{background-image: url(images/placeholder.png) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}.vc_custom_1443407464843{background-color: #f7f7f7 !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}.vc_custom_1447470412294{padding-right: 0px !important;padding-left: 0px !important;}.vc_custom_1454660872979{margin-top: 25px !important;margin-bottom: 50px !important;}.vc_custom_1453351085654{padding-right: 0px !important;padding-left: 0px !important;}.vc_custom_1448213759990{margin-top: 36px !important;margin-bottom: 63px !important;}</style>
   <noscript>
      <style type="text/css"> .wpb_animate_when_almost_visible { opacity: 1; }</style>
   </noscript>
